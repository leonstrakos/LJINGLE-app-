#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const APP_MARKER = '// codexNativePdfSelectionBridgeAppV2';
const NATIVE_MARKER = '// codexNativePdfSelectionBridgeV1';

function occurrences(source, needle) {
  return source.split(needle).length - 1;
}

function ensure(source, label, done, candidates, replacement) {
  if (done(source)) return source;
  for (const candidate of candidates) {
    const count = occurrences(source, candidate);
    if (count === 1) return source.replace(candidate, replacement);
    if (count > 1) {
      throw new Error(`${label}: expected 1 match for a candidate, found ${count}`);
    }
  }
  throw new Error(`${label}: source is a different reader revision; no safe anchor found`);
}

function readText(file) {
  return fs.readFileSync(file, 'utf8');
}

function writeText(file, source) {
  fs.writeFileSync(file, source);
}

function locateRoot() {
  const roots = [
    process.env.LJINGLE_ROOT,
    process.cwd(),
    path.join(process.cwd(), 'mobile'),
    path.join(process.cwd(), 'app'),
  ]
    .filter(Boolean)
    .map((value) => path.resolve(value));

  for (const root of roots) {
    if (fs.existsSync(path.join(root, 'src', 'components', 'BookReaderModal.tsx'))) {
      return root;
    }
  }
  throw new Error('LJingle root not found. Run from the app root or set LJINGLE_ROOT.');
}

function patchBookReader(root) {
  const file = path.join(root, 'src', 'components', 'BookReaderModal.tsx');
  let source = readText(file);

  source = ensure(
    source,
    'reader type import',
    (value) => /\bReaderSelectionRect\b/.test(value),
    ['  BookReaderTheme,\n  ReaderEntryAnchor,'],
    '  BookReaderTheme,\n  ReaderSelectionRect,\n  ReaderEntryAnchor,',
  );

  source = ensure(
    source,
    'selection state',
    (value) => /const \[pdfSelectionRects, setPdfSelectionRects\]/.test(value),
    ["  const [selectedText, setSelectedText] = useState('');"],
    `  const [selectedText, setSelectedText] = useState('');
  const [pdfSelectionRects, setPdfSelectionRects] = useState<ReaderSelectionRect[]>([]);
  ${APP_MARKER}`,
  );

  source = ensure(
    source,
    'selection reset',
    (value) => /setSelectedText\(''\);\n\s*setPdfSelectionRects\(\[\]\);/.test(value),
    [
      '    setEpubProgress(document.progress);\n    setReaderError(null);',
      '    setEpubProgress(document.progress);\n    setSelectedText(\'\');\n    setReaderError(null);',
    ],
    '    setEpubProgress(document.progress);\n    setSelectedText(\'\');\n    setPdfSelectionRects([]);\n    setReaderError(null);',
  );

  if (!/if \(!quote\.trim\(\)\) setPdfSelectionRects\(\[\]\);/.test(source)) {
    const manualSelectionAnchor = /(const beginNote = \(quote = ''(?:, asQuote = false)?\) => \{[\s\S]*?setSelectedText\(quote\.trim\(\)\);)(\r?\n)(\s*setNoteType\()/;
    const matches = source.match(new RegExp(manualSelectionAnchor.source, 'g')) || [];
    if (matches.length !== 1) {
      throw new Error(`manual note selection: expected 1 semantic beginNote match, found ${matches.length}`);
    }
    source = source.replace(
      manualSelectionAnchor,
      '$1$2    if (!quote.trim()) setPdfSelectionRects([]);$2$3',
    );
  }

  source = ensure(
    source,
    'persist selection rects',
    (value) => /selectionRects: document\.format === 'PDF' \? pdfSelectionRects : null,/.test(value),
    [
      '        selectedText: selectedText || null,',
      "        selectedText: (noteType === 'QUOTE' ? noteContent.trim() : selectedText.trim()) || null,",
    ],
    "        selectedText: (noteType === 'QUOTE' ? noteContent.trim() : selectedText.trim()) || null,\n        selectionRects: document.format === 'PDF' ? pdfSelectionRects : null,",
  );

  if (!/highlightRects=\{(?:pdfSelectionRects|\[\.\.\.pdfHighlights, \.\.\.pdfSelectionRects\])\}/.test(source)) {
    if (/highlightRects=\{pdfHighlights\}/.test(source)) {
      source = source.replace(
        '                highlightRects={pdfHighlights}',
        '                highlightRects={[...pdfHighlights, ...pdfSelectionRects]}',
      );
    } else {
      source = ensure(
        source,
        'PDF selection props',
        (value) => /highlightRects=\{pdfSelectionRects\}/.test(value),
        ['                enablePaging={false}\n                horizontal={false}'],
        '                enablePaging={false}\n                horizontal={false}\n                pdfId={document.documentId}\n                highlightRects={pdfSelectionRects}',
      );
    }
  }

  source = ensure(
    source,
    'native text callback',
    (value) => /onTextSelected=\{\(selection:/.test(value),
    ['                page={Math.max(1, initialPage ?? document.currentPage ?? 1)}'],
    `                onTextSelected={(selection: { text?: string; page?: number; rects?: ReaderSelectionRect[] }) => {
                  const quote = String(selection?.text ?? '').trim();
                  if (!quote) return;
                  setPage(Math.max(1, Number(selection.page) || page));
                  setSelectedText(quote);
                  setPdfSelectionRects(Array.isArray(selection.rects) ? selection.rects : []);
                  setNoteType('QUOTE');
                  setNoteContent(quote);
                  setPanel(null);
                }}
                page={Math.max(1, initialPage ?? document.currentPage ?? 1)}`,
  );

  if (!source.includes(APP_MARKER)) {
    source += `\n${APP_MARKER}\n`;
  }
  writeText(file, source);
}

function patchReaderTypes(root) {
  const file = path.join(root, 'src', 'types', 'reader.ts');
  if (!fs.existsSync(file)) return;
  let source = readText(file);

  source = ensure(
    source,
    'reader selection type',
    (value) => /export type ReaderSelectionRect =/.test(value),
    ["export type BookReaderTheme = 'DAY' | 'NIGHT';"],
    "export type BookReaderTheme = 'DAY' | 'NIGHT';\n\nexport type ReaderSelectionRect = {\n  page: number;\n  rect: string;\n};",
  );
  source = ensure(
    source,
    'reader anchor rect type',
    (value) => /selectionRects: ReaderSelectionRect\[\];/.test(value),
    ['  selectedText: string | null;\n  createdAt:'],
    '  selectedText: string | null;\n  selectionRects: ReaderSelectionRect[];\n  createdAt:',
  );
  source = ensure(
    source,
    'reader preview rect type',
    (value) => /\| 'selectionRects'/.test(value),
    ["  | 'selectedText'\n>;"],
    "  | 'selectedText'\n  | 'selectionRects'\n>;",
  );
  writeText(file, source);
}

function patchReaderRepository(root) {
  const file = path.join(root, 'src', 'services', 'bookReaderRepository.ts');
  if (!fs.existsSync(file)) return;
  let source = readText(file);

  source = ensure(
    source,
    'anchor row selection rects',
    (value) => /selection_rects: string \| null;/.test(value),
    ['  selected_text: string | null;\n  created_at:'],
    '  selected_text: string | null;\n  selection_rects: string | null;\n  created_at:',
  );

  source = ensure(
    source,
    'map selection rects',
    (value) => /let selectionRects: ReaderEntryAnchor\['selectionRects'\]/.test(value),
    ['function mapAnchor(row: AnchorRow): ReaderEntryAnchor {\n  return {'],
    `function mapAnchor(row: AnchorRow): ReaderEntryAnchor {
  let selectionRects: ReaderEntryAnchor['selectionRects'] = [];
  if (row.selection_rects) {
    try {
      const parsed = JSON.parse(row.selection_rects);
      if (Array.isArray(parsed)) {
        selectionRects = parsed.filter((value) => value && Number.isFinite(Number(value.page)) && typeof value.rect === 'string');
      }
    } catch {
      selectionRects = [];
    }
  }
  return {`,
  );

  source = ensure(
    source,
    'mapped selection rects',
    (value) => /selectedText: row\.selected_text \?\? null,\n    selectionRects,/.test(value),
    ['    selectedText: row.selected_text ?? null,\n    createdAt:'],
    '    selectedText: row.selected_text ?? null,\n    selectionRects,\n    createdAt:',
  );

  source = ensure(
    source,
    'anchor schema',
    (value) => /selected_text TEXT,\n\s*selection_rects TEXT,/.test(value),
    ['      selected_text TEXT,\n      created_at TEXT NOT NULL,'],
    '      selected_text TEXT,\n      selection_rects TEXT,\n      created_at TEXT NOT NULL,',
  );

  source = ensure(
    source,
    'anchor migration',
    (value) => /ALTER TABLE reader_entry_anchors ADD COLUMN selection_rects TEXT/.test(value),
    ['  `);\n\n  return database;'],
    `  \`);

  try {
    await database.runAsync('ALTER TABLE reader_entry_anchors ADD COLUMN selection_rects TEXT');
  } catch {
    // Existing database already has the additive column.
  }

  return database;`,
  );

  source = ensure(
    source,
    'anchor save input',
    (value) => /selectionRects\?: ReaderEntryAnchor\['selectionRects'\] \| null;/.test(value),
    ['  selectedText?: string | null;\n}) {'],
    "  selectedText?: string | null;\n  selectionRects?: ReaderEntryAnchor['selectionRects'] | null;\n}) {",
  );

  source = ensure(
    source,
    'anchor insert columns',
    (value) => /selected_text, selection_rects, created_at, modified_at\)/.test(value),
    ['      selected_text, created_at, modified_at)\n     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'],
    '      selected_text, selection_rects, created_at, modified_at)\n     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
  );

  source = ensure(
    source,
    'anchor update columns',
    (value) => /selection_rects=excluded\.selection_rects/.test(value),
    ['       selected_text=excluded.selected_text,\n       modified_at=excluded.modified_at`,'],
    '       selected_text=excluded.selected_text,\n       selection_rects=excluded.selection_rects,\n       modified_at=excluded.modified_at`,',
  );

  source = ensure(
    source,
    'anchor insert value',
    (value) => /input\.selectionRects && input\.selectionRects\.length > 0/.test(value),
    ['    input.selectedText?.trim() || null,\n    now,'],
    "    input.selectedText?.trim() || null,\n    input.selectionRects && input.selectionRects.length > 0 ? JSON.stringify(input.selectionRects) : null,\n    now,",
  );

  source = ensure(
    source,
    'anchor preview query type',
    (value) => /selected_text: string \| null;\n    selection_rects: string \| null;/.test(value),
    ['    selected_text: string | null;\n  }>(\n    `SELECT anchor_id, entry_id, document_id, book_id, format, page,\n            epub_locator, selected_text\n'],
    '    selected_text: string | null;\n    selection_rects: string | null;\n  }>(\n    `SELECT anchor_id, entry_id, document_id, book_id, format, page,\n            epub_locator, selected_text, selection_rects\n',
  );

  source = ensure(
    source,
    'anchor preview mapping',
    (value) => /selectionRects: row\.selection_rects/.test(value),
    ['      selectedText: row.selected_text ?? null,\n    };'],
    `      selectedText: row.selected_text ?? null,
      selectionRects: row.selection_rects ? (() => {
        try {
          const parsed = JSON.parse(row.selection_rects);
          return Array.isArray(parsed) ? parsed.filter((value) => value && Number.isFinite(Number(value.page)) && typeof value.rect === 'string') : [];
        } catch {
          return [];
        }
      })() : [],
    };`,
  );

  writeText(file, source);
}

function findPatchFile() {
  const candidates = [
    path.join(__dirname, 'react-native-pdf-jsi-native-selection.patch'),
    path.join(process.cwd(), 'react-native-pdf-jsi-native-selection.patch'),
  ];
  return candidates.find((file) => fs.existsSync(file)) || null;
}

function installPackagePatch(root) {
  const patchSource = findPatchFile();
  if (!patchSource) {
    throw new Error('Missing react-native-pdf-jsi-native-selection.patch next to this installer. Extract the supplied ZIP first.');
  }
  const patchDir = path.join(root, 'patches');
  fs.mkdirSync(patchDir, { recursive: true });
  const patchTarget = path.join(patchDir, 'react-native-pdf-jsi+4.4.2.patch');
  fs.copyFileSync(patchSource, patchTarget);

  const packageFile = path.join(root, 'package.json');
  if (fs.existsSync(packageFile)) {
    const pkg = JSON.parse(readText(packageFile));
    pkg.devDependencies = pkg.devDependencies || {};
    if (!pkg.dependencies?.['patch-package'] && !pkg.devDependencies['patch-package']) {
      pkg.devDependencies['patch-package'] = '8.0.0';
    }
    pkg.scripts = pkg.scripts || {};
    if (!String(pkg.scripts.postinstall || '').includes('patch-package')) {
      pkg.scripts.postinstall = pkg.scripts.postinstall
        ? `${pkg.scripts.postinstall} && patch-package`
        : 'patch-package';
    }
    writeText(packageFile, JSON.stringify(pkg, null, 2) + '\n');
  }

  const installed = path.join(root, 'node_modules', 'react-native-pdf-jsi');
  if (fs.existsSync(installed)) {
    try {
      execFileSync('patch', ['--batch', '--forward', '-p1', '-i', patchTarget], {
        cwd: installed,
        stdio: 'inherit',
      });
    } catch {
      console.warn('Native package patch will be applied during npm install/postinstall.');
    }
  }
}

function backup(root) {
  const timestamp = new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14);
  const dir = path.join(root, '_recovery', `reader-native-selection-v2-repair-${timestamp}`);
  fs.mkdirSync(dir, { recursive: true });
  const files = [
    'src/components/BookReaderModal.tsx',
    'src/types/reader.ts',
    'src/services/bookReaderRepository.ts',
    'package.json',
    'patches/react-native-pdf-jsi+4.4.2.patch',
  ];
  const manifest = [];
  for (const relative of files) {
    const source = path.join(root, relative);
    if (!fs.existsSync(source)) continue;
    const target = path.join(dir, relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
    manifest.push(relative);
  }
  fs.writeFileSync(path.join(dir, 'manifest.json'), JSON.stringify({ files: manifest }, null, 2) + '\n');
  return dir;
}

function restore(root, recovery) {
  const manifest = JSON.parse(readText(path.join(recovery, 'manifest.json')));
  for (const relative of manifest.files) {
    const source = path.join(recovery, relative);
    const target = path.join(root, relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
}

function isComplete(root) {
  const reader = path.join(root, 'src', 'components', 'BookReaderModal.tsx');
  const types = path.join(root, 'src', 'types', 'reader.ts');
  const repository = path.join(root, 'src', 'services', 'bookReaderRepository.ts');
  const patch = path.join(root, 'patches', 'react-native-pdf-jsi+4.4.2.patch');
  if (![reader, types, repository, patch].every((file) => fs.existsSync(file))) return false;
  const readerSource = readText(reader);
  const typesSource = readText(types);
  const repositorySource = readText(repository);
  return (
    readerSource.includes(APP_MARKER) &&
    readerSource.includes('onTextSelected={(selection:') &&
    (readerSource.includes('highlightRects={pdfSelectionRects}') ||
      readerSource.includes('highlightRects={[...pdfHighlights, ...pdfSelectionRects]}')) &&
    typesSource.includes('export type ReaderSelectionRect =') &&
    typesSource.includes("| 'selectionRects'") &&
    repositorySource.includes('selection_rects TEXT') &&
    repositorySource.includes('input.selectionRects')
  );
}

function main() {
  const root = locateRoot();
  if (isComplete(root)) {
    console.log('Native PDF selection bridge is already complete — no changes made.');
    return;
  }
  const recovery = backup(root);
  try {
    patchBookReader(root);
    patchReaderTypes(root);
    patchReaderRepository(root);
    installPackagePatch(root);
    console.log('Native PDF selection bridge repaired/installed successfully.');
    console.log(`Recovery backup: ${recovery}`);
    console.log('Next: npm install, then rebuild the Android development/preview build.');
  } catch (error) {
    restore(root, recovery);
    throw error;
  }
}

main();
